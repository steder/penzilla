from NumPtr import getpointer
from NumPtr import verifypointer
