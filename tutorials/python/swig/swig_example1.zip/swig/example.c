#include <stdio.h>
#include <stdlib.h>

int cube( int n )
{
  return n * n * n;
}
